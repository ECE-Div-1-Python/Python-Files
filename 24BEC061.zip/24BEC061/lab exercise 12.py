#q1
"""class ComplexNumber:
    def __init__(self, real, imaginary):
        # Initialize the real and imaginary parts
        self.real = real
        self.imaginary = imaginary

    def __repr__(self):
        # String representation for displaying the complex number
        return f"{self.real} + {self.imaginary}i"

    def __add__(self, other):
        # Addition of two complex numbers
        return ComplexNumber(self.real + other.real, self.imaginary + other.imaginary)

    def __sub__(self, other):
        # Subtraction of two complex numbers
        return ComplexNumber(self.real - other.real, self.imaginary - other.imaginary)

    def __mul__(self, other):
        # Multiplication of two complex numbers
        real_part = self.real * other.real - self.imaginary * other.imaginary
        imaginary_part = self.real * other.imaginary + self.imaginary * other.real
        return ComplexNumber(real_part, imaginary_part)

    def __truediv__(self, other):
        # Division of two complex numbers
        denominator = other.real**2 + other.imaginary**2
        if denominator == 0:
            raise ValueError("Cannot divide by zero.")
        real_part = (self.real * other.real + self.imaginary * other.imaginary) / denominator
        imaginary_part = (self.imaginary * other.real - self.real * other.imaginary) / denominator
        return ComplexNumber(real_part, imaginary_part)

# Example usage:
# Create two complex numbers
num1 = ComplexNumber(4, 5)  # 4 + 5i
num2 = ComplexNumber(2, 3)  # 2 + 3i

# Perform addition
result_add = num1 + num2
print(f"Addition: {num1} + {num2} = {result_add}")

# Perform subtraction
result_sub = num1 - num2
print(f"Subtraction: {num1} - {num2} = {result_sub}")

# Perform multiplication
result_mul = num1 * num2
print(f"Multiplication: {num1} * {num2} = {result_mul}")

# Perform division
try:
    result_div = num1 / num2
    print(f"Division: {num1} / {num2} = {result_div}")
except ValueError as e:
    print(e)"""
#q2
"""class Matrix:
    def __init__(self, data):
        # Initialize the matrix with a 3x3 list of lists
        self.data = data

    def __repr__(self):
        # String representation for displaying the matrix
        return '\n'.join(['\t'.join(map(str, row)) for row in self.data])

    def __add__(self, other):
        # Matrix addition: Add corresponding elements of two matrices
        result = [[self.data[i][j] + other.data[i][j] for j in range(3)] for i in range(3)]
        return Matrix(result)

    def __mul__(self, other):
        # Matrix multiplication: Perform matrix multiplication with another matrix
        result = [[sum(self.data[i][k] * other.data[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
        return Matrix(result)

    def transpose(self):
        # Transpose the matrix: Swap rows and columns
        result = [[self.data[j][i] for j in range(3)] for i in range(3)]
        return Matrix(result)


# Example usage:
matrix1 = Matrix([[1, 2, 3], [4, 5, 6], [7, 8, 9]])  # 3x3 Matrix
matrix2 = Matrix([[9, 8, 7], [6, 5, 4], [3, 2, 1]])  # Another 3x3 Matrix

# Print the original matrices
print("Matrix 1:")
print(matrix1)
print("\nMatrix 2:")
print(matrix2)

# Matrix addition
result_add = matrix1 + matrix2
print("\nMatrix Addition (Matrix1 + Matrix2):")
print(result_add)

# Matrix multiplication
result_mul = matrix1 * matrix2
print("\nMatrix Multiplication (Matrix1 * Matrix2):")
print(result_mul)

# Matrix transpose
result_transpose1 = matrix1.transpose()
result_transpose2 = matrix2.transpose()
print("\nTranspose of Matrix1:")
print(result_transpose1)
print("\nTranspose of Matrix2:")
print(result_transpose2)"""
#q3
"""import math

class Solid:
    def __init__(self, shape, *dimensions):
        # Initialize the shape and its dimensions
        self.shape = shape.lower()
        self.dimensions = dimensions

    def surface_area(self):
        # Calculate surface area based on the shape
        if self.shape == 'cube':
            side = self.dimensions[0]
            return 6 * side ** 2
        elif self.shape == 'sphere':
            radius = self.dimensions[0]
            return 4 * math.pi * radius ** 2
        elif self.shape == 'cylinder':
            radius, height = self.dimensions
            return 2 * math.pi * radius * (radius + height)
        else:
            raise ValueError("Shape not supported")

    def volume(self):
        # Calculate volume based on the shape
        if self.shape == 'cube':
            side = self.dimensions[0]
            return side ** 3
        elif self.shape == 'sphere':
            radius = self.dimensions[0]
            return (4/3) * math.pi * radius ** 3
        elif self.shape == 'cylinder':
            radius, height = self.dimensions
            return math.pi * radius ** 2 * height
        else:
            raise ValueError("Shape not supported")

# Example usage:

# Create a Cube with side length 3
cube = Solid('cube', 3)
print(f"Cube Surface Area: {cube.surface_area()} units²")
print(f"Cube Volume: {cube.volume()} units³")

# Create a Sphere with radius 5
sphere = Solid('sphere', 5)
print(f"\nSphere Surface Area: {sphere.surface_area()} units²")
print(f"Sphere Volume: {sphere.volume()} units³")

# Create a Cylinder with radius 4 and height 7
cylinder = Solid('cylinder', 4, 7)
print(f"\nCylinder Surface Area: {cylinder.surface_area()} units²")
print(f"Cylinder Volume: {cylinder.volume()} units³")"""
#q4
import math

class RegularShape:
    def __init__(self, shape, *dimensions):
        """
        Initializes the shape and its dimensions.
        
        :param shape: Type of shape (e.g., 'square', 'circle', 'polygon')
        :param dimensions: Relevant dimensions for the shape (e.g., side length, radius, number of sides)
        """
        self.shape = shape.lower()
        self.dimensions = dimensions

    def perimeter(self):
        """
        Calculates the perimeter (or circumference) based on the shape.
        
        :return: Perimeter or circumference of the shape
        """
        if self.shape == 'square':
            side = self.dimensions[0]
            return 4 * side
        elif self.shape == 'circle':
            radius = self.dimensions[0]
            return 2 * math.pi * radius
        elif self.shape == 'polygon':
            side_length, num_sides = self.dimensions
            return side_length * num_sides
        else:
            raise ValueError("Shape not supported")

    def area(self):
        """
        Calculates the area based on the shape.
        
        :return: Area of the shape
        """
        if self.shape == 'square':
            side = self.dimensions[0]
            return side ** 2
        elif self.shape == 'circle':
            radius = self.dimensions[0]
            return math.pi * radius ** 2
        elif self.shape == 'polygon':
            side_length, num_sides = self.dimensions
            # Formula for area of a regular polygon: (n * s^2) / (4 * tan(π / n))
            return (num_sides * side_length ** 2) / (4 * math.tan(math.pi / num_sides))
        else:
            raise ValueError("Shape not supported")

# Example usage:

# Create a Square with side length 5
square = RegularShape('square', 5)
print(f"Square Perimeter: {square.perimeter()} units")
print(f"Square Area: {square.area()} units²")

# Create a Circle with radius 7
circle = RegularShape('circle', 7)
print(f"\nCircle Circumference: {circle.perimeter()} units")
print(f"Circle Area: {circle.area()} units²")

# Create a Regular Polygon (e.g., Hexagon) with side length 4 and 6 sides
polygon = RegularShape('polygon', 4, 6)
print(f"\nPolygon (Hexagon) Perimeter: {polygon.perimeter()} units")
print(f"Polygon (Hexagon) Area: {polygon.area()} units²")

#q5
"""class Time:
    def __init__(self, hours=0, minutes=0, seconds=0):
        
        self.hours = hours
        self.minutes = minutes
        self.seconds = seconds
        self.normalize_time()

    def normalize_time(self):
       
        # Normalize seconds
        if self.seconds >= 60:
            self.minutes += self.seconds // 60
            self.seconds = self.seconds % 60
        # Normalize minutes
        if self.minutes >= 60:
            self.hours += self.minutes // 60
            self.minutes = self.minutes % 60
        # Normalize hours (optional, you can limit it to 24 hours if needed)
        if self.hours >= 24:
            self.hours = self.hours % 24

    def __repr__(self):
        #String representation of time object.
        return f"{self.hours:02}:{self.minutes:02}:{self.seconds:02}"

    def __add__(self, other):
        #Add two Time objects.
        total_seconds = self.to_seconds() + other.to_seconds()
        return Time.from_seconds(total_seconds)

    def __sub__(self, other):
        #Subtract two Time objects.
        total_seconds = self.to_seconds() - other.to_seconds()
        return Time.from_seconds(total_seconds)

    def __eq__(self, other):
        
        return self.to_seconds() == other.to_seconds()

    def __lt__(self, other):
        
        return self.to_seconds() < other.to_seconds()

    def __le__(self, other):
        

    def __gt__(self, other):
        
        return self.to_seconds() > other.to_seconds()

    def __ge__(self, other):
        
        return self.to_seconds() >= other.to_seconds()

    def to_seconds(self):
        
        return self.hours * 3600 + self.minutes * 60 + self.seconds

    @classmethod
    def from_seconds(cls, total_seconds):
        
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        return cls(hours, minutes, seconds)

# Example usage:

# Create time objects
time1 = Time(2, 45, 30)  # 2 hours, 45 minutes, 30 seconds
time2 = Time(1, 15, 50)  # 1 hour, 15 minutes, 50 seconds

# Print the time objects
print(f"Time 1: {time1}")
print(f"Time 2: {time2}")

# Perform addition of time
time_add = time1 + time2
print(f"Time1 + Time2 = {time_add}")

# Perform subtraction of time
time_sub = time1 - time2
print(f"Time1 - Time2 = {time_sub}")

# Perform comparison
print(f"Time1 == Time2? {time1 == time2}")
print(f"Time1 < Time2? {time1 < time2}")
print(f"Time1 > Time2? {time1 > time2}")"""
#q6
"""class Date:
    def __init__(self, day, month, year):
        
        self.day = day
        self.month = month
        self.year = year

    def __repr__(self):
        
        return f"{self.day:02}/{self.month:02}/{self.year}"

    def __eq__(self, other):
       
        if isinstance(other, Date):
            return self.day == other.day and self.month == other.month and self.year == other.year
        return False

# Example usage:

# Create two Date objects
date1 = Date(15, 7, 2023)
date2 = Date(15, 7, 2023)
date3 = Date(16, 7, 2023)

# Print the Date objects
print(f"Date 1: {date1}")
print(f"Date 2: {date2}")
print(f"Date 3: {date3}")

# Compare two Date objects
print(f"Date1 == Date2? {date1 == date2}")  # Should be True
print(f"Date1 == Date3? {date1 == date3}")  # Should be False
"""
#q7
"""class Weather:
    def __init__(self, *parameters):
        
        self.weather_parameters = list(parameters)

    def __repr__(self):
        
        return f"Weather Parameters: {', '.join(self.weather_parameters)}"

    def __contains__(self, item):
        
        return item in self.weather_parameters

# Example usage:

# Create a Weather object with some weather parameters
weather = Weather('Temperature', 'Humidity', 'Wind Speed', 'Precipitation')

# Print the Weather object
print(weather)

# Check if certain weather parameters are present using 'in' operator
print(f"Is 'Temperature' a weather parameter? {'Temperature' in weather}")  # Should be True
print(f"Is 'Cloud Cover' a weather parameter? {'Cloud Cover' in weather}")  # Should be False
"""
#q8
"""class String:
    def __init__(self, value=""):
        
        self.value = value

    def __repr__(self):
        
        return f"String('{self.value}')"

    def __iadd__(self, other):
        
        if isinstance(other, String):
            self.value += other.value  # Concatenate the value of another String object
        elif isinstance(other, str):
            self.value += other  # Concatenate a regular string
        else:
            raise TypeError("The operand must be a string or a String object")
        return self

    def toLower(self):
        
        self.value = self.value.lower()

    def toUpper(self):
        
        self.value = self.value.upper()

# Example usage:

# Create String objects
str1 = String("Hello")
str2 = String(" World")

# Perform string concatenation using overloaded '+=' operator
str1 += str2
print(f"After concatenation: {str1}")

# Convert string to lowercase
str1.toLower()
print(f"After toLower(): {str1}")

# Convert string to uppercase
str1.toUpper()
print(f"After toUpper(): {str1}")"""


