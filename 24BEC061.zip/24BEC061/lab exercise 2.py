#q1
#method 1
"""a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

largest = max(a, b)
smallest = min(a, b)
print("Largest value:", largest)
print("Smallest value:", smallest)"""
#method 2
"""a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
if (a>b):
    print(a,"is the larger number.")
else:
    print(b,"is the larger number.")"""
#q2
"""a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))

if (a>b>c):
    print(a,"is the largest number.")
    print(c,"is the smallest number.")
elif(b>c):
    print(b,"is the largest number.")
    print((min(a,c)), "is the smallest number")
else:
    print(c, "is the largest number")"""
#q3
"""a = int(input("Enter first number: "))
if (a%2 == 0):
    print("even")
else:
    print("odd")"""
#q4
"""a = int(input("Enter first number: "))
if (a%10 == 0):
    print(a, "is divisible by 10")
else:
    print("not divisible by 10")"""
#q5
"""age = int (input("enter your age: "))
if (age>18):
    print("major")
else:
    print("minor")"""
#q6
"""a = str(input("Enter first number: "))
l = len(a)
print(l)"""
#q7
"""year = int(input("Enter a year: "))

# Check leap year conditions
if (year % 4 == 0):
    if (year % 100 == 0):
        if (year % 400 == 0):
            print(year, "is a leap year.")
        else:
            print(year, "is not a leap year.")
    else:
        print(year, "is a leap year.")
else:
    print(year, "is not a leap year.")"""
#q8
"""angle_1 = float(input("enter angle in degrees : "))
angle_2 = float(input("enter angle in degrees : "))
angle_3 = float(input("enter angle in degrees : "))
if (angle_1 + angle_2 + angle_3 == 180):
    print("triangle is valid")
else:
    print("triangle is not valid")"""
#q9
"""a = int(input("enter a number:"))
if (a>0):
    print(a)
elif (a==0):
    print(a)
else:
    print((-a))"""
#q10
"""l = int(input("enter length:"))
b = int(input("enter breadth:"))
area = l*b
perimeter = 2*(l+b)
if (area>perimeter):
    print("area")
elif(area == perimeter):
    print("both are equal")
else:
    print("perimeter")"""
#q11
#method1
"""# Input three points
x1, y1 = map(float, input("Enter x1 y1: ").split())
x2, y2 = map(float, input("Enter x2 y2: ").split())
x3, y3 = map(float, input("Enter x3 y3: ").split())

# Use cross multiplication to avoid division (to handle vertical lines)
if (x2 - x1) * (y3 - y2) == (y2 - y1) * (x3 - x2):
    print("All three points lie on the same straight line.")
else:
    print("The points do NOT lie on the same straight line.")"""
#method2
"""# Input three points
x1 = float(input("Enter x1: "))
y1 = float(input("Enter y1: "))

x2 = float(input("Enter x2: "))
y2 = float(input("Enter y2: "))

x3 = float(input("Enter x3: "))
y3 = float(input("Enter y3: "))

# Check if the points are collinear using cross multiplication
if (x2 - x1) * (y3 - y2) == (y2 - y1) * (x3 - x2):
    print("All three points lie on the same straight line.")
else:
    print("The points do NOT lie on the same straight line.")"""
#q12
"""#center coordinates
h = int(input("enter h:"))
k = int(input("enter k:"))
#coordinates of point
x = int(input("enter x:"))
y = int(input("enter y:"))
radius = int(input("enter radius of the circle:"))
distance = (((x-h)**2)+ ((y-k)**2))** (1/2)

if (distance>radius):
    print("outside")
elif(distance == radius):
    print("point lies on the circle")
else:
    print("inside")"""
#q13
"""# Input a number
num = int(input("Enter a number between 0 and 19: "))

# Check and print the word equivalent
if num == 0:
    print("zero")
elif num == 1:
    print("one")
elif num == 2:
    print("two")
elif num == 3:
    print("three")
elif num == 4:
    print("four")
elif num == 5:
    print("five")
elif num == 6:
    print("six")
elif num == 7:
    print("seven")
elif num == 8:
    print("eight")
elif num == 9:
    print("nine")
elif num == 10:
    print("ten")
elif num == 11:
    print("eleven")
elif num == 12:
    print("twelve")
elif num == 13:
    print("thirteen")
elif num == 14:
    print("fourteen")
elif num == 15:
    print("fifteen")
elif num == 16:
    print("sixteen")
elif num == 17:
    print("seventeen")
elif num == 18:
    print("eighteen")
elif num == 19:
    print("nineteen")
else:
    print("Number out of range! Please enter between 0 and 19.")"""
#q14
"""maths = int(input("enter the marks of maths:"))
phy = int(input("enter the marks of phy:"))
chem = int(input("enter the marks of chem:"))
total_marks = maths+phy+chem
avg = total_marks /3
print(" total marks:" , total_marks)
print("average:",avg)

if (maths or phy or chem > 39):
    print("FAIL")
if(40 < maths and phy and chem <44):
    print("P")
if(45 < maths and phy and chem <49):
    print("c")
if(50 < maths and phy and chem <54):
    print("B")
if(55 < maths and phy and chem <59):
    print("B+")
if(60 < maths and phy and chem <69):
    print("A")
if(70 < maths and phy and chem <79):
    print("A+")
if(80 < maths and phy and chem <100):
    print("O")"""




        




    
    

