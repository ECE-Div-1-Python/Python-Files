#q1
"""user_input = input("Enter a string: ")
# Define the vowels
vowels = "aeiouAEIOU"
# Initialize a counter
vowel_count = 0
# Count the vowels
for char in user_input:
    if char in vowels:
        vowel_count += 1

# Print the result
print("Number of vowels:", vowel_count)"""
#q2

"""def to_lower_case(text):
    result = ""
    for char in text:
        if 'A' <= char <= 'Z':  # Check if it's uppercase
            # Convert to lowercase by adding 32
            result += chr(ord(char) + 32)
        else:
            result += char
    return result

def to_upper_case(text):
    result = ""
    for char in text:
        if 'a' <= char <= 'z':  # Check if it's lowercase
            # Convert to uppercase by subtracting 32
            result += chr(ord(char) - 32)
        else:
            result += char
    return result

def toggle_case(text):
    result = ""
    for char in text:
        if 'a' <= char <= 'z':
            result += chr(ord(char) - 32)  # to uppercase
        elif 'A' <= char <= 'Z':
            result += chr(ord(char) + 32)  # to lowercase
        else:
            result += char
    return result

# Example usage:
user_input = input("Enter a string: ")

print("Lower case:", to_lower_case(user_input))
print("Upper case:", to_upper_case(user_input))
print("Toggle case:", toggle_case(user_input))"""
#q3
"""str1 = input("enter string 1:")
str2 = input("enter string 2:")
if str2 in str1:
    print("string 2 is present in string 1")
else:
    print("string 2 is not present in string 1")"""
#q4
"""str1 = input("enter the string:")
remove_str = input("enter the string which has to be removed:")
final = str1.replace (remove_str,'')
print(final)"""

    

