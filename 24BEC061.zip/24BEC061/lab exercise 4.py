#example 1
"""ls = ['cat', 'dog', 'tiger', 'lion', 'leopard']
for i, ele in enumerate(ls):
    print(i, ele)"""
#q1
"""# Print uppercase letters
print("Uppercase Alphabets:")
for i in range(65, 91):  # ASCII values from 'A' to 'Z'
    print(chr(i), end=' ')
print("\n")

# Print lowercase letters
print("Lowercase Alphabets:")
for i in range(97, 123):  # ASCII values from 'a' to 'z'
    print(chr(i), end=' ')
print()"""
#q2
"""num = int(input("Enter a number to print its multiplication table: "))

for i in range(1, 11):
    print(f"{num} x {i} = {num * i}")"""
#q3

"""# Get input from the user
input_string = input("Enter a string: ")

# Initialize counters
alphabet_count = 0
digit_count = 0

# Loop through each character in the string
for char in input_string:
    if char.isalpha():
        alphabet_count += 1
    elif char.isdigit():
        digit_count += 1

# Display the result
print(f"\nNumber of Alphabets: {alphabet_count}")
print(f"Number of Digits: {digit_count}")"""
#q4
#method1
"""def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

def is_perfect(n):
    sum_factors = sum([i for i in range(1, n) if n % i == 0])
    return sum_factors == n

def is_armstrong(n):
    num_str = str(n)
    power = len(num_str)
    return n == sum(int(digit) ** power for digit in num_str)

def is_palindrome(n):
    return str(n) == str(n)[::-1]

def is_automorphic(n):
    square = n ** 2
    return str(square).endswith(str(n))

# Get number input from the user
num = int(input("Enter a number: "))

# Check and display results
print(f"\nResults for number {num}:")

print("Prime Number?     :", "Yes" if is_prime(num) else "No")
print("Perfect Number?   :", "Yes" if is_perfect(num) else "No")
print("Armstrong Number? :", "Yes" if is_armstrong(num) else "No")
print("Palindrome?        :", "Yes" if is_palindrome(num) else "No")
print("Automorphic?       :", "Yes" if is_automorphic(num) else "No")"""
#method 2
#checking for prime
"""num = int(input("enter a number:"))
if num>1:
    for i in range(2,num):
        if(num%i == 0):
            print(num, "is not a prime number")
            break
        else:
            print(num, "is a prime number")
else:
    print(num,"is not a prime number")"""
#checking for perfect
"""n = int(input("enter a number:"))
divisor_sum = 0
for i in range(1,n):
    if n%1 == 0:
        divisor_sum +=i
if divisor_sum == n:
    print(n, "is a perfect number")
else:
    print(n, "is not a perfect number")"""
    
#checking for armstrong
"""num = int (input("enter a number:"))
num_str = str(num)
length = len(num_str)
sum =0
for digit in num_str:
    sum += int(digit)**length
if sum==num:
    print(num,"is an armstrong number")
else:
    print(num, "is not an armstrong number")"""
#checking for palindrome
"""n = int(input("enter a number:"))
if str(n) == str(n)[::-1]:
    print(n,"is a palindrome")
else:
    print(n,"is not a palindrome")"""
    
#checking for automorphic
"""n = int(input("enter a number:"))
square = n**2
str_n = str(n)
str_square = str(square)
if str_square.endswith(str_n):
    print(n,"is an automorphic number")
else:
    print(n,"is not an automorphic number")"""
#q5
"""limit = 30
triplets=[]
for a in range(1, limit+1):
    for b in range(a, limit+1):
        for c in range(b, limit+1):
            if a**2 + b**2 ==c**2:
                triplets.append((a,b,c))
print("pythagorean triplets :")
for triplet in triplets:
    print(triplet)"""
#q6
"""for h in range(1,12):
    print(f"{h} am")
print("12 noon")
for h in range(1,12):
    print(f"{h} pm")
print("12 midnight")"""
#q7
"""def factorial(n):
    if n ==0 or n==1:
        return 1
    return n* factorial (n-1)
n = int (input("enter n:"))
r =int (input("enter r:"))

nCr =  factorial(n) // factorial(r) * factorial (n-r)
nPr = factorial(n) // factorial (n-r)
print(f" nCr:{nCr}, nPr: {nPr}")"""
#q8
"""n = int(input("enter a number:"))
factorial = 1
for i in range(1,n+1):
    factorial *= i
print(f"the factorial of {n} is {factorial}")"""
#q9
"""n = int(input("enter a number:"))
for i in range(n,0,-1):
    print(i, end= ' ')"""
#q10
"""n = int(input("enter the number of terms:"))
a,b = 0,1
print(a,b, end = '')
for _ in range(n-2):
    a,b = b, a+b
    print(b, end= ' ' )"""
#q11
"""import math
x_deg = float(input("enter angle in degrees:"))
x = x_deg * (math.pi /180)
sin_x =0
for i in range(10):
    term = ((-1) ** i) * (x **(2*i+1)) / math.factorial(2*i+1)
    sin_x += term
print(f" sin {x_deg} = {sin_x}")"""

    

    
            
    
    





