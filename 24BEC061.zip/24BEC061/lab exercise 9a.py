#q1
"""def fun():
    print("This is function fun()")

def disp():
    print("This is function disp()")

def msg():
    print("This is function msg()")

# Store functions in a list
functions = [fun, disp, msg]

# Call each function using a loop
for f in functions:
    f()
"""
#q2
"""# Define the two lists
list1 = [1, 2, 3, 4, 5, 6]
list2 = [6, 5, 4, 3, 2, 1]

# Use map and lambda to add corresponding elements
result = list(map(lambda x, y: x + y, list1, list2))

# Print the result
print("Resultant list:", result)"""
#q3
"""import random

# Generate a list of 10 different random numbers between -15 and 15
random_numbers = random.sample(range(-15, 16), 10)

# Create a new list with the squares of the numbers
squared_numbers = list(map(lambda x: x ** 2, random_numbers))

# Print the random numbers and their squares
print("Random numbers:", random_numbers)
print("Squared numbers:", squared_numbers)"""
#q4
"""# Define the list
lst = ['madam', 'Python', 'malayalam', 12321]

# Function to check if a string is a palindrome
def is_palindrome(s):
    # Convert the input to a string and check if it reads the same forwards and backwards
    s = str(s)
    return s == s[::-1]

# Iterate over the list and print the palindromes
for item in lst:
    if is_palindrome(item):
        print(item)"""
#q5
"""# List of faculty members
faculty_names = ['Alice', 'Jonathan', 'Christopher', 'Michael', 'Sarah', 'Elizabeth', 'Daniel']

# Use list comprehension to filter names with length greater than 8
filtered_names = [name for name in faculty_names if len(name) > 8]

# Print the filtered names
print("Faculty members with names longer than 8 characters:", filtered_names)"""



