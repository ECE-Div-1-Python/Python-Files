#q1
"""def count_lower_upper(s):
    
    # Initialize counts
    lower_count = 0
    upper_count = 0
    
    # Loop through each character in the string
    for char in s:
        if char.islower():
            lower_count += 1
        elif char.isupper():
            upper_count += 1
    
    # Return counts as a dictionary
    return {"lowercase": lower_count, "uppercase": upper_count}

# Sample usage:
sample_string = "Hello World! Python is FUN!"
result = count_lower_upper(sample_string)

# Print the result
print("Counts of lowercase and uppercase letters:", result)"""
#q2
"""def compute(n):
    
    # Convert the digit to string to easily concatenate
    str_n = str(n)
    
    # Calculate the value of n + nn + nnn + nnnn
    result = n + int(str_n * 2) + int(str_n * 3) + int(str_n * 4)
    
    return result

# Test the function for digits 4 to 7
for digit in range(4, 8):
    print(f"Result for {digit}: {compute(digit)}")"""
#q3
"""def create_array(x, y, z, value):
    
    return [[[value for _ in range(z)] for _ in range(y)] for _ in range(x)]

# Example usage:
array_3d = create_array(3, 4, 5, 7)

# Print the 3D array
for i, layer in enumerate(array_3d):
    print(f"Layer {i + 1}:")
    for row in layer:
        print(row)
    print()  # Newline for separation between layers"""
#q4
"""def sum_avg(marks):
    
    if len(marks) != 5:
        raise ValueError("Exactly 5 marks must be provided.")
    
    total = sum(marks)
    average = total / 5
    
    return total, average

# Example usage:
marks = [85, 90, 78, 92, 88]
total, average = sum_avg(marks)

print(f"Total Marks: {total}")
print(f"Average Marks: {average}")"""
#q5
"""import string

def ispangram(sentence):
    
    # Set of all lowercase English letters
    alphabet_set = set(string.ascii_lowercase)
    
    # Convert the sentence to lowercase and make a set of its characters
    sentence_set = set(sentence.lower())
    
    # Check if all alphabet letters are present in the sentence
    return alphabet_set <= sentence_set  # or alphabet_set.issubset(sentence_set)

# Test examples
test1 = "The quick brown fox jumps over the lazy dog"
test2 = "Crazy Fredrick bought many very exquisite opal jewels"
test3 = "This is not a pangram"

# Run tests
print(f"Is pangram (test1)? {ispangram(test1)}")
print(f"Is pangram (test2)? {ispangram(test2)}")
print(f"Is pangram (test3)? {ispangram(test3)}")"""
#q6
"""def generate_tuples(end):
    
    return [(x, x**2, x**3) for x in range(1, end + 1)]

# Example usage:
result = generate_tuples(5)
print("Generated tuples:")
for tup in result:
    print(tup)"""
#q7
"""def ispalindrome(s):
    
    # Remove spaces and convert to lowercase
    cleaned = ''.join(s.lower().split())
    
    # Compare the cleaned string with its reverse
    return cleaned == cleaned[::-1]

# Example usage:
test_strings = [
    "Madam",
    "nurses run",
    "RaceCar",
    "Was it a car or a cat I saw",
    "Hello World"
]

# Test the function
for text in test_strings:
    result = ispalindrome(text)
    print(f"'{text}' -> Palindrome? {result}")
"""
#q8
"""def convert(s):
    
    words = s.split()              # Split the string into words
    unique_words = set(words)      # Remove duplicates
    sorted_words = sorted(unique_words)  # Sort words alphanumerically
    return ' '.join(sorted_words)  # Join them back into a string

# Example usage:
input_str = "banana apple orange apple mango banana grape"
result = convert(input_str)
print("Converted string:", result)"""
#q9
"""def count_alpha_digits(s):
    
    alpha_count = 0
    digit_count = 0
    
    for char in s:
        if char.isalpha():
            alpha_count += 1
        elif char.isdigit():
            digit_count += 1
    
    return {"alphabets": alpha_count, "digits": digit_count}

# Example usage:
input_str = "Python3.10 is released in 2021!"
result = count_alpha_digits(input_str)

print("Counts:", result)"""
#q10
"""def frequency(text):
    
    words = text.split()  # Split the string into words
    freq_dict = {}

    # Count frequency of each word
    for word in words:
        word = word.lower()  # Optional: make case-insensitive
        freq_dict[word] = freq_dict.get(word, 0) + 1

    # Sort the dictionary by keys (words)
    sorted_freq = dict(sorted(freq_dict.items()))

    return sorted_freq

# Example usage:
input_text = "apple banana apple orange Banana orange apple"
result = frequency(input_text)

print("Word Frequencies (sorted):")
for word, count in result.items():
    print(f"{word}: {count}")"""
#q11
"""def create_list(list1, list2):
    
    return list(set(list1) & set(list2))

# Example usage:
a = [1, 2, 3, 4, 5]
b = [3, 4, 5, 6, 7]

result = create_list(a, b)
print("Intersection of the two lists:", result)"""
#RECURSIVE FUNCTIONS
#q1
"""def prime_factors(n, divisor=2):
    
    # Base case: when n becomes 1, return an empty list (no more factors)
    if n == 1:
        return []
    
    # If n is divisible by divisor, it's a prime factor
    if n % divisor == 0:
        return [divisor] + prime_factors(n // divisor, divisor)
    else:
        # Otherwise, try the next divisor
        return prime_factors(n, divisor + 1)

# Example usage:
number = int(input("Enter a positive integer: "))
factors = prime_factors(number)

print(f"The prime factors of {number} are: {factors}")"""
#q2
"""def to_binary(n):
   
    if n == 0:
        return ''
    else:
        return to_binary(n // 2) + str(n % 2)

# Example usage:
number = int(input("Enter a positive integer: "))

if number == 0:
    print("Binary equivalent: 0")
else:
    binary = to_binary(number)
    print(f"Binary equivalent of {number} is: {binary}")"""
#q3
"""def count_vowels(s):
    
    if s == "":
        return 0
    elif s[0].lower() in "aeiou":
        return 1 + count_vowels(s[1:])
    else:
        return count_vowels(s[1:])

# Example usage:
input_str = input("Enter a string: ")
vowel_count = count_vowels(input_str)

print(f"Number of vowels in the string: {vowel_count}")"""
#q4
"""def reverse_list(lst):
    
    if len(lst) <= 1:
        return lst
    else:
        return [lst[-1]] + reverse_list(lst[:-1])

# Example usage:
numbers = [1, 2, 3, 4, 5]
reversed_numbers = reverse_list(numbers)

print("Original List:", numbers)
print("Reversed List:", reversed_numbers)"""
#q5
"""def power(a, b):
    
    if b == 0:
        return 1
    else:
        return a * power(a, b - 1)

# Example usage:
a = int(input("Enter the base (a): "))
b = int(input("Enter the exponent (b): "))

if b < 0:
    print("This function only handles non-negative exponents.")
else:
    result = power(a, b)
    print(f"{a} raised to the power {b} is: {result}")"""
#q6
"""def sanitize_list(lst):
    
    if not lst:  # Base case: empty list
        return []
    else:
        head = 0 if lst[0] < 0 else lst[0]
        return [head] + sanitize_list(lst[1:])

# Example usage:
numbers = [3, -1, 7, -4, 0, 5, -6]
sanitized = sanitize_list(numbers)

print("Original List:", numbers)
print("Sanitized List:", sanitized)"""
#q7
"""def average_recursive(lst, index=0, total=0):
    
    if index == len(lst):  # Base case: all elements processed
        return total / len(lst) if lst else 0
    else:
        return average_recursive(lst, index + 1, total + lst[index])

# Example usage:
numbers = [10, 20, 30, 40, 50]
avg = average_recursive(numbers)

print("List of numbers:", numbers)
print("Average:", avg)"""
#q8
"""def string_length(s):
    
    if s == "":  # Base case: empty string
        return 0
    else:
        return 1 + string_length(s[1:])

# Example usage:
text = input("Enter a string: ")
length = string_length(text)

print(f"Length of the string is: {length}")"""

















