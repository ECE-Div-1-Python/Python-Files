#lab 01
#1
a = 5
b = 3
sum_result = a + b
print("Sum:", sum_result)

#2
a = 8
b = 3
difference = a - b
print("Difference:", difference)

#3
a = 6
b = 4
product = a * b
print("Product:", product)

#4
a = 10
b = 2
quotient = a / b
print("Quotient:", quotient)

#5
a = 12
b = 6
sum_result = a + b
difference = a - b
product = a * b
quotient = a / b
print("Sum:", sum_result)
print("Difference:", difference)
print("Product:", product)
print("Quotient:", quotient)

#6
hours = 2
minutes = hours * 60
print("Minutes:", minutes)

#7
minutes = 120
hours = minutes / 60
print("Hours:", hours)

#8
dollars = 10
rupees = dollars * 48
print("Rupees:", rupees)

#9
rupees = 240
dollars = rupees / 48
print("Dollars:", dollars)

#10
dollars = 10
rupees = dollars * 48
pounds = rupees / 70
print("Pounds:", pounds)

#11
grams = 5000
kg = grams / 1000
print("Kilograms:", kg)

#12
kg = 5
grams = kg * 1000
print("Grams:", grams)

#13
bytes_value = 1048576
kb = bytes_value / 1024
mb = kb / 1024
gb = mb / 1024
print("KB:", kb)
print("MB:", mb)
print("GB:", gb)

#14
celsius = 25
fahrenheit = (9/5 * celsius) + 32
print("Fahrenheit:", fahrenheit)

#15
fahrenheit = 77
celsius = 5/9 * (fahrenheit - 32)
print("Celsius:", celsius)

#16
P = 1000 
R = 5
N = 2 
interest = (P * R * N) / 100
print("Interest:", interest)

#17
L = 4
area = L ** 2
perimeter = 4 * L
print("Area:", area)
print("Perimeter:", perimeter)

#18
L = 5
B = 3
area = L * B
perimeter = 2 * (L + B)
print("Area:", area)
print("Perimeter:", perimeter)

#19
R = 7
area = (22/7) * R * R
print("Area of Circle:", area)

#20
H = 10
L = 5
area = (H * L) / 2
print("Area of Triangle:", area)

#21
gross_salary = 50000
allowance = 0.10 * gross_salary
deduction = 0.03 * gross_salary
net_salary = gross_salary + allowance - deduction
print("Net Salary:", net_salary)

#22
gross_sales = 10000
discount = 0.10 * gross_sales
net_sales = gross_sales - discount
print("Net Sales:", net_sales)

#23
sub1 = 85
sub2 = 90
sub3 = 80
total = sub1 + sub2 + sub3
average = total / 3
print("Total Marks:", total)
print("Average Marks:", average)

#24
a = 5
b = 10
a, b = b, a # Swaps values
print("After Swap: a =", a,"b =", b)